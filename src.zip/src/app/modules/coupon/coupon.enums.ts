export enum COUPON_DISCOUNT_TYPE {
   FLAT = 'Flat',
   PERCENTAGE = 'Percentage',
}
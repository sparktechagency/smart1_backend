export enum FAQType {
     SERVICE = 'Service',
     CMS = 'Cms',
}

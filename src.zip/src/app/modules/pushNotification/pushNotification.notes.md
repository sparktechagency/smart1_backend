<!-- sdfsdfdsf -->

- create project in firebase console e.g "kappes"
- then go to (_just change the project id_): https://console.firebase.google.com/project/  kappes-aeb17  /settings/serviceaccounts/adminsdk
- click "generate new private key" button
- then download the json file
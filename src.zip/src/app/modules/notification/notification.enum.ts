export enum NOTIFICATION_MODEL_TYPE {
    USER = 'User',
    PAYMENT = 'Payment',
    MESSAGE = 'Message',
    BOOKING = 'Booking',
    NOTIFICATION = 'Notification',
}
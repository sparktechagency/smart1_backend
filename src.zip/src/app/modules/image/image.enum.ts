export enum ImageType {
    SLIDER_IMAGE = 'sliderImage',
    LOGO = 'logo',
    ONBOARDING_IMAGE = 'onboardingImage',
    IMAGE = 'image',
    BANNER = 'banner',
}